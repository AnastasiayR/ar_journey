import pygame
class Button:
    def __init__(self, screen, width, height, activ_col=(50,168, 186), inactiv_col=(60, 200, 230),
                 turn_on='image/mute_on.png', turn_off='image/mute_off.png',
                 image_activ='image/pixil-frame-0 (5).png', image_inactiv='image/pixil-frame-0 (4).png'):
        self.screen = screen
        self.height = height
        self.width = width
        self.activ_col = activ_col
        self.inactiv_col = inactiv_col
        self.turn_on = self.load_image(turn_on)
        self.turn_off = self.load_image(turn_off)
        self.swith_image = {True: self.turn_on,
                            False: self.turn_off}
        self.image_activ = self.load_image(image_activ)
        self.image_inactiv = self.load_image(image_inactiv)
        self.volum = True


    def load_image(self, image):
        return pygame.image.load(image)



    def draw(self, but_x, but_y, messege, action = None, argument = None, sound=None, shrift = 'arial', size=30, volum=True):
        self.volum=volum
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if but_x < mouse[0] < but_x + self.width and but_y < mouse[1] < but_y+self.height:
            pygame.draw.rect(self.screen, self.activ_col, (but_x, but_y, self.width, self.height))
            if click[0] ==1 and action!=None:
                self.sounds_play(sound)
                if argument is None:
                    action()
                else:
                    action(argument)
                pygame.time.delay(100)
        else:
            pygame.draw.rect(self.screen, self.inactiv_col, (but_x, but_y, self.width, self.height))

        mes = pygame.font.SysFont(shrift, size)
        text = mes.render(messege, True, (0, 0, 0))
        self.screen.blit(text, (but_x+10, but_y+10))

    def sounds_play(self, sound=None):
        if sound is not None and self.volum is True:
            sound.play()


    def draw_sign(self,but_x, but_y, action=None, swither=None, argument=None, sound=None, volum=True):
        self.volum = volum
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if swither is not None:
            image = self.swith_image[swither]
        else:
            image = self.turn_on
        if but_x < mouse[0] < but_x + self.width and but_y < mouse[1] < but_y + self.height:
            self.screen.blit(self.screen, (but_x, but_y), (but_x-self.height, but_y, self.width, self.height))
            self.screen.blit(image, (but_x+10, but_y-10))
            if click[0] == 1 and action is not None:
                self.sounds_play(sound)
                if argument is None:
                    action()
                else:
                    action(argument)
                pygame.time.delay(300)
        else:
            self.screen.blit(self.screen, (but_x, but_y), (but_x-self.height, but_y, self.width, self.height))
            self.screen.blit(image, (but_x, but_y))


    def draw_but(self, but_x, but_y, messege, action = None, argument = None, sound=None, shrift = 'arial', size=20, volum=True):
        self.volum = volum
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if but_x < mouse[0] < but_x + self.width and but_y < mouse[1] < but_y+self.height:
            self.image_activ = pygame.transform.scale(self.image_activ, (self.width, self.height))
            self.screen.blit(self.image_activ, (but_x, but_y))
            if click[0] == 1 and action!=None:
                self.sounds_play(sound)
                if argument is None:
                    action()
                else:
                    action(argument)
                pygame.time.delay(100)
        else:
            self.image_inactiv = pygame.transform.scale(self.image_inactiv, (self.width, self.height))
            self.screen.blit(self.image_inactiv, (but_x, but_y))

        mes = pygame.font.SysFont(shrift, size)
        text = mes.render(messege, True, (0, 0, 0))
        self.screen.blit(text, (but_x+self.width//8, but_y+(self.height-20)//2))

