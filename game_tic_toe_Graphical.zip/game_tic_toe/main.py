import pygame
import random
from button import Button
import sys


class Player:
    list_sign = {'X': 'image/pixil-frame-0.png', '0': 'image/pixil-frame-1.png'}

    def __init__(self, name, sign):
        self.name = name
        self.sign = sign
        self.image = pygame.image.load(self.list_sign[sign])
        self.II = False


class Board:
    dict_square = {1: (80, 110),
                   2: (240, 110),
                   3: (400, 110),
                   4: (80, 270),
                   5: (240, 270),
                   6: (400, 270),
                   7: (80, 430),
                   8: (240, 430),
                   9: (400, 430)}
    all_win_var = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
        [1, 4, 7],
        [2, 5, 8],
        [3, 6, 9],
        [1, 5, 9],
        [3, 5, 7]
    ]

    def __init__(self):
        self.board = [[1, 2, 3],
                      [4, 5, 6],
                      [7, 8, 9]]
        self.lock_cell = []
        self.history_step = {'X': [], '0': []}

    def end_step(self, player, cell):
        self.lock_cell.append(cell)
        self.history_step[player.sign].append(cell)

    def check(self):

        """ Проверка на окончание партии (собрана ли линия) """

        for i_str in self.board:
            if i_str[0] == i_str[1] == i_str[2]:
                ind = self.board.index(i_str)
                pygame.draw.line(screen, (255, 0, 0),
                                 (start_x + width_cell*0.2, start_y+height_cell*0.5 +(height_cell+size_space) * ind),
                                 (start_x + width_cell*(3-0.2), start_y+height_cell*0.5 + (height_cell+size_space) * ind),
                                 10)
                return True, False
        for k in range(len(self.board)):
            if self.board[0][k] == self.board[1][k] == self.board[2][k]:
                ind = k
                pygame.draw.line(screen, (255, 0, 0),
                                 (start_x + width_cell*0.5 + (width_cell+size_space) * ind, start_y+height_cell*0.2),
                                 (start_x+ width_cell*0.5 + (width_cell+size_space) * ind, start_y+height_cell*(3-0.2)),
                                 10)
                return True, False
        if self.board[0][0] == self.board[1][1] == self.board[2][2]:
            pygame.draw.line(screen, (255, 0, 0), (start_x + width_cell*0.2, start_y+height_cell*0.2),
                             (start_x + width_cell*(3-0.2), start_y+height_cell*(3-0.2)), 10)
            return True, False
        if self.board[2][0] == self.board[1][1] == self.board[0][2]:
            pygame.draw.line(screen, (255, 0, 0), (start_x + width_cell*0.2, start_y+height_cell*(3-0.2)),
                             (start_x + width_cell*(3-0.2), start_y+height_cell*0.2), 10)
            return True, False
        if len(self.lock_cell) == 9:
            return True, True

        return False, False


class Game:
    def __init__(self, players):
        self.players = players
        self.num_party = 1
        self.result = {players[0].name: 0,
                       players[1].name: 0}


def draw_text(message, collor=(0, 0, 0), text_width=300, text_height=50, shrift='arial', size=20, fon=None):
    format_t = pygame.font.SysFont(shrift, size)
    text = format_t.render(message, True, collor, fon)
    screen.blit(text, (text_width, text_height))


def main_menu():

    """ Главное меню
    Начало партии или выход (закрытие) игрового окна """
    global button_mute
    screen.blit(back, (0, 0))
    draw_text(f'Крестики-нолики', text_width=125, text_height=100, shrift='gabriola', size=75)
    button_main = Button(screen, 250, 60)
    show = True
    while show:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # событие которое стартует после нажатия крестика
                sys.exit()
        button_main.draw_but(100, 225, 'Игра на двоих', start_game, sound=click, volum=status_mute)
        button_main.draw_but(100, 300, 'Игра с компьютером', start_game, True, sound=click, volum=status_mute)
        button_main.draw_but(100, 375, 'Выход', close_game, sound=click, volum=status_mute)
        button_mute.draw_sign(mute_x, mute_y, action=mute, swither=status_mute)
        pygame.display.update()


def mute():
    global status_mute
    if status_mute is True:
        pygame.mixer.music.stop()
        status_mute = False
    else:
        pygame.mixer.music.play(-1)
        status_mute = True
    pygame.display.update()


def step(pos, board, player):
    cell = search_cell(pos, board.dict_square)
    for i in board.board:
        for j in i:
            if cell is None or cell in board.lock_cell:
                if status_mute is True and not (mute_x < pos[0] < mute_x + 64 and mute_y < pos[1] < mute_y + 64):
                    missclick.play()
                return restep(board, player)
            if cell == j and cell not in board.lock_cell:
                draw_step(cell, board, player)
                return


def draw_step(cell, board, player):
    line = int((cell - 0.1) // 3)
    col = cell % 3 - 1
    board.board[line][col] = player.sign
    screen.blit(player.image, board.dict_square[cell])
    pygame.display.update()
    board.end_step(player, cell)
    return


def random_step(board, player):

    lock = board.lock_cell
    user_cell = board.history_step['X']
    comp_cell = board.history_step['0']
    open_cell = []
    for var in board.all_win_var:
        count_emp, count_comp = 0, 0
        empty, empty_comp = None, None
        for cell in var:
            if cell not in comp_cell:
                empty_comp = cell
                count_comp += 1
            if cell not in user_cell:
                empty = cell
                count_emp += 1
        if count_comp == 1 and empty_comp not in lock:
            return draw_step(empty_comp, board, player)
        if count_emp == 1 and empty not in lock:
            open_cell.append(empty)
    if len(open_cell) == 0:
        open_cell = [num for num in board.dict_square.keys() if num not in lock]
    return draw_step(random.choice(open_cell), board, player)


def search_cell(coor, dict_squear):
    """ определяем по координатам в какую ячейку произведено нажатие мышкой.
    На вход принимаються фактические координаты нажатия (кортеж x,y).
    Возвращаются координаты левого верхнего угла выбранной ячейки"""
    x, y = coor[0], coor[1]
    for num, (sq_x, sq_y) in dict_squear.items():
        if sq_x <= x <= sq_x+width_cell and sq_y <= y <= sq_y+height_cell:
            return num

    button_mute.draw_sign(mute_x, mute_y, action=mute, swither=status_mute)
    button_return.draw_sign(100, mute_y, action=main_menu)
    pygame.display.update()
    return None


def restep(board, player):
    """ Повторный выбор ячейки в случае выбора занятой ячейки или мисклика """
    steps = True
    while steps:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # событие которое стартует после нажатия крестика
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                return step(pygame.mouse.get_pos(), board, player)
        button_mute.draw_sign(mute_x, mute_y, action=mute, swither=status_mute)
        button_return.draw_sign(100, mute_y, action=main_menu)
        pygame.display.update()


def finish_party(player, end=False):
    """Окно после окончания партии
    Вывод результатов, выбор дальнейшего деяствия: начать следующую партию или выход на главное меню"""
    wind = pygame.Surface((WIDTH, HEIGHT))
    wind.fill((255, 255, 255))
    wind.set_alpha(100)
    screen.blit(wind, (0, 0))
    pygame.display.update()
    game.num_party += 1
    draw_text(f'Партия окончена', text_width=150, text_height=125, size=50, fon=(200, 200, 200))

    if end is True:
        draw_text(f'Нет ходов', text_width=250, text_height=200, size=36, fon=(200, 200, 200))
    else:
        game.result[player.name] += 1
    draw_text(f'{game.players[0].name}:    {game.result[game.players[0].name]}', text_width=80, text_height=250,
              size=36, fon=(200, 200, 200))
    draw_text(f'{game.players[1].name}:    {game.result[game.players[1].name]}', text_width=80, text_height=300,
              size=36, fon=(200, 200, 200))

    button_cont = Button(screen, 300, 50)
    pygame.display.update()
    pygame.time.delay(300)
    fin = True
    while fin:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # событие которое стартует после нажатия крестика
                sys.exit()

        button_cont.draw_but(100, 400, 'Продолжить', start_party, sound=click, volum=status_mute)
        button_cont.draw_but(100, 475, 'Главное меню', main_menu, sound=click, volum=status_mute)
        button_mute.draw_sign(mute_x, mute_y, action=mute,swither=status_mute)
        pygame.display.update()


def close_game():
    sys.exit()


def start_game(sec_pl=False):
    """Начало игровой сессии. Создана игра для ведения статистики (турнирной таблицы для одной сессии"""
    global game
    play_1 = Player('Player-X', 'X')
    play_2 = Player('Player-0', '0')
    game = Game([play_1, play_2])
    if sec_pl is True:
        play_2.II = True
    start_party()


def start_party():
    # создали поле и играков
    gameboard = Board()
    player = random.choice(game.players)
    # графически создали поле
    screen.blit(back, (0, 0))
    screen.blit(net, (start_x, start_y))
    draw_text(f'Партия:{game.num_party}', text_width=500, text_height=30)
    draw_text(f'Ход игрока: {player.name}', text_width=70, text_height=50)

    pygame.display.update()
    games = True
    while games:
        clock.tick(FPS)
        button_mute.draw_sign(mute_x, mute_y, action=mute, swither=status_mute)
        button_return.draw_sign(100, mute_y, action=main_menu)
        pygame.display.update()
        for event in pygame.event.get():

            if event.type == pygame.QUIT:  # событие которое стартует после нажатия крестика
                sys.exit()
            if player.II is False and event.type == pygame.MOUSEBUTTONDOWN:
                step(pygame.mouse.get_pos(), gameboard, player)
                result, end = gameboard.check()  # Проверка итогов партии
                if result is True:
                    finish_party(player, end)
                player = switch_player(player)
        if player.II is True:
            pygame.time.delay(700)
            random_step(gameboard, player)
            result, end = gameboard.check()  # Проверка итогов партии
            if result is True:
                finish_party(player, end)
            player = switch_player(player)
        pygame.event.clear()

def switch_player(player):
    if player == game.players[0]:
        player = game.players[1]
    else:
        player = game.players[0]
    screen.blit(back, (70, 50), (70, 50, 200, 20))
    draw_text(f'Ход игрока: {player.name}', text_width=70, text_height=50)
    pygame.display.update()
    return player


WIDTH = 640
HEIGHT = 640
FPS = 30
width_cell, height_cell = 150, 150
size_space = 10
width_board = width_cell*3 + size_space*2
height_board = height_cell*3 + size_space*2
start_x, start_y = 80, 110
mute_x, mute_y = 550, 570

pygame.init()
pygame.font.init()

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("My game windows")

missclick = pygame.mixer.Sound('sound/miss.ogg')
click = pygame.mixer.Sound('sound/click_1.ogg')
click.set_volume(0.2)
pygame.mixer.music.load('sound/backsound.mp3')
pygame.mixer.music.set_volume(0.05)
missclick.set_volume(1.5)


back = pygame.image.load('image/backround.png')
net = pygame.image.load('image/pixil-frame-0 (3).png')
icon = pygame.image.load('image/icon.png')
return_but = 'image/back.png'
button_mute = Button(screen, 64, 64)
button_return = Button(screen, 64, 64, turn_on=return_but)

status_mute = True
pygame.mixer.music.play(-1)
pygame.display.set_icon(icon)
pygame.display.flip()
clock = pygame.time.Clock()

main_menu()
