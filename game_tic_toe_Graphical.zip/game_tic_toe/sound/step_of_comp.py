import random

all_win_var = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [1, 4, 7],
    [2, 5, 8],
    [3, 6, 9],
    [1, 5, 9],
    [3, 5, 7]
]
class Board:

    lock_cell =[]
    history_step = {'X': [], '0': []}

def random_step(board):
    lock = board.lock_cell
    user_cell = board.history_step['X']
    open_cell = []
    for var in all_win_var:
        count = 0
        empty = None
        for cell in var:
            if cell not in user_cell and empty is None:
                empty=cell
            if cell not in user_cell and empty is not None:
                break
            count+=1
        if count == 3 and empty not in lock:
            open_cell.append(empty)
        if open_cell == []:
            return random.choice(list(board.dict_squear.values()))

    return board.dict_squear[random.choice(open_cell)]

